// filesystem.h

#include  "myfilesystem.h"

FSClass::FSClass(){}

void FSClass::initFileSystem(){

    bool DataFileOK = false;

    Serial.flush();
    Serial.println(" ");
    log_i("Init FileSystem");

    // Expicit formatting of the filesystem (must be done before mounting)
    // formatFileSystem();

    // Mount the filesystem
    // NOTE: `begin(true)` means to auto-format if mounting fails!
    if (myFS->begin(true)) log_i("   File system '%s' was mounted successfully", myFSName);
    else                   log_e("   Couldn't mount filesystem  '%s'", myFSName);

    cSF(fname, 35);                                                 // filename
    fname.printf("/TEST%ik.cam", FILESIZE);                         // like: /TEST300k.cam

    if (myFS->exists(fname.c_str())){                               // file does exist
        File file = myFS->open(fname.c_str());
        if (file.size() / 1024 == FILESIZE ) DataFileOK = true;     // file is of correct size
    }

    if (DataFileOK) {
        // Data file found and size ok
        log_i("   Found data file '%s' of proper size: %i KB", fname.c_str(), FILESIZE);
    }
    else{
        // Data file missing or of incorrect size

        removeFullDir("/");                                   // delete dir with all its content

        // uncomment next line to make 500k file as first thing on filesystem in root dir
        makeCAMFile(500 * 1024U, "/root500k.cam");

        log_i("   Making data file %s of size: %i", fname.c_str(), FILESIZE);    // make test file
        makeCAMFile(FILESIZE * 1024U, fname.c_str());
    }

    log_i("   Filesystem size: Total:%4u KB, Used:%4u KB, Free:%4u KB"
                            , myFS->totalBytes() / kibi
                            , myFS->usedBytes()  / kibi
                            , (myFS->totalBytes() - myFS->usedBytes()) / kibi
                            );

    // Show listing of files
    cSF(flist, 2000, "   File Listing:\n");
    addDirFileListSystem(flist, "/", 0);
    log_i("%s", flist.c_str() );
}


void FSClass::makeCAMFile(uint32_t fsize, const char * fname){
    // fsize is filesize in bytes
    // file is written with 32 printable-ASCII chars per record
    // with 4MB ESP32 max is 1460 kB -> 1495040 Bytes

    const   uint8_t     bpr         = 32;     // size of a record
    const   uint8_t     record[bpr] = {48,49,50,51,52,53,54,55,56,57,                                       // coding: 0 ... 9
                                       65,66,67,68,69,70,71,72,73,74,75,76,77,78,79,80,81,82,83,84,85,86};  // coding: A ... V; no terminating \0 !
            File        file;

    auto t0 = micros();
    log_i("   makeCAMFile: with size: %i", fsize);

    file = myFS->open(fname, "w");     // clear file
    file.close();

    file = myFS->open(fname, "rb+");   // open for binary reading and writing
    for(uint32_t i = 0; i < fsize / bpr; i++){
        file.write(record, bpr);
        yield();
    }
    file.close();

    float dur = (micros() - t0) / 1000.0f;
    log_i("   makeCAMFile: finished in %0.1f ms", dur);
}


void FSClass::addDirFileListSystem(SafeString & flist, const char * dirname, uint8_t level){
// call like :  addDirFileListSystem(misc, "/", 0)

            File                root;
            File                file;
    static  uint32_t            totalfsize;

    if (level == 0) {
        totalfsize  = 0;
        flist      +=  ("File                                    Bytes      KB");
    }

    root = myFS->open(dirname);
    if(!root){
        flist.printf("ERR: Failed to open directory '%s'", dirname);
        return;
    }

    if(!root.isDirectory()) {
        flist.printf("ERR: '%s' is not a directory",       dirname);
        return;
    }

    file = root.openNextFile();
    while(file){
        if(file.isDirectory()){
            addDirFileListSystem(flist, file.name(), level + 1);
        }
        else {
            size_t fsize  = file.size();                    // the size of the file in Bytes
            flist.printf("\n%-37s%8i %7.1f", file.name(), fsize, (float)fsize / kibi);
            totalfsize  += fsize;
        }
        file = root.openNextFile();
    }

    if (level == 0) {
        flist.printf("\nTOTAL:  %29s%8i %7.1f", "", totalfsize, (float)totalfsize / kibi);
    }
}


void FSClass::removeFile(const char * filename){
// bool VFSImpl::exists(const char* path)
// on LITTLEFS remove fails if filename does not exist; check with exists first

    cSF(rf, 200, "REMOVE FILE ");

    if (myFS->exists(filename)){
        if (!myFS->remove(filename)) rf.printf("'%s' Failed with error", filename);
        else                         rf.printf("'%s' Done OK", filename);
    }
    else                             rf.printf("'%s' - not possible, it does not exist", filename);

    log_i("%s", rf.c_str());
}


bool FSClass::formatFileSystem(){

    bool formatted = false;
    cSF(msg, 100);

    log_i("   Formatting File System '%s'   ", myFSName);

//FFat
    //bool format(bool full_wipe = FFAT_WIPE_QUICK, char* partitionLabel = (char*)FFAT_PARTITION_LABEL);
    //Wipe disk: quick just wipes the FAT. Full zeroes the whole disk
    //              #define FFAT_WIPE_QUICK 0
    //              #define FFAT_WIPE_FULL 1
    #if   myFSCode == 1
        formatted = FFat.format(FFAT_WIPE_FULL);

//SPIFFS
    //bool format();
    #elif myFSCode == 2
        formatted = SPIFFS.format();

//LittleFS
    //bool format();
    #elif myFSCode == 3
        formatted = LITTLEFS.format();

    #endif

    if(formatted) msg = "Success";
    else          msg = "FAILURE";

    log_i("   %s", msg.c_str());

    return formatted;
}


bool FSClass::removeFullDir(const char * dirname){

    File root;
    File file;

    root = myFS->open(dirname);
    if(!root){
        log_e("ERR: Failed to open directory: '%s'", dirname);
        return false;
    }

    if(!root.isDirectory()) {
        log_e("ERR: '%s' is not a directory",       dirname);
        return false;
    }

    log_i("Dir name: %s", root.name());

    file = root.openNextFile();
    while(file){
        log_i("Removing file: %s", file.name());
        myFS->remove(file.name());
        file = root.openNextFile();
    }

    myFS->rmdir(dirname);

    return true;
}

