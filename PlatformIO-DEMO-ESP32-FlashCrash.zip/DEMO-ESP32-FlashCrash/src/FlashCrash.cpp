// mymain.cpp

#include "FlashCrash.h"
#include "myfilesystem.h"
#include "mynvs.h"
#include "mywebserver.h"
#include "mywifi.h"

#include <rom/spi_flash.h>                  // gives Flash info

const uint32_t      mibi                    = 1024 * 1024;
const uint32_t      kibi                    = 1024;
const uint32_t      FlashID                 = g_rom_flashchip.device_id;            // 6 digits
const uint32_t      FlashSize               = spi_flash_get_chip_size();            // in Byte
const String        filePath                = "/TEST" + String(FILESIZE) + "k.cam"; // like: 'TEST300k.cam'

uint32_t            countOfBoots            = 0;        // number of boots; stored in NVS
uint32_t            countOfDownloads        = 0;        // number of downloads; stored in NVS
uint32_t            totalcountOfDnlds       = 0;        // total number of downloads
uint32_t            waitperiod              = WAITFAST; // alt: WAITSLOW; to allow fast/slow webpage refreshing

#if   myFSCode == 1                                     // using the FFat file system
    #include "FFat.h"
    fs::F_Fat       * myFS                  = &FFat;

#elif myFSCode == 2                                     // using the SPIFFS file system
    #include "SPIFFS.h"
    fs::SPIFFSFS   *  myFS                  = &SPIFFS;

#elif myFSCode == 3                                     // using the LittleFS file system
    #include "LITTLEFS.h"
    fs::LITTLEFSFS  * myFS                  = &LITTLEFS;

#endif

NVSClass myNVSclass;
FSClass  myFSClass;


/******************************************************************************
 * setup
 *****************************************************************************/
void setup(){
    Serial.begin(SERIAL_BAUDRATE);
    Serial.setDebugOutput(true);            // allow Debug output on Serial
    SafeString::setOutput(Serial);          // activate SafeString debug output on Serial
    delay(1000);
    Serial.println("setup started #######################################################################################");

    // extra logging for errors
    esp_log_level_set("*", ESP_LOG_ERROR);  // altern: ESP_LOG_INFO

    // get the config for max priorities
    log_i("configMAX_PRIORITIES: %d", configMAX_PRIORITIES);

    // get Flash info
    log_i("Flash Chip Size: %0.2f MB  (%u Bytes)", (float)FlashSize / mibi, FlashSize);
    log_i("Flash Chip id  : %6x, manufacturer: %2x, device: %4x", FlashID, FlashID >> 16, FlashID & 0xFFFF);

    myFSClass.initFileSystem();

    myNVSclass.initNVS();

    initWiFi();

    initWebServer();

    yield();  // needed ?

    Serial.flush();
    Serial.printf("setup finished -----------------------------------------------------------------  countOfBoots: %u\n", countOfBoots);
}


/******************************************************************************
 * Loop
 *****************************************************************************/
void loop(){
    static uint32_t mydelay = 100;
    static uint32_t trial   = 1;

    // check for WiFi connection
    if (!WiFi.isConnected()){
        log_e("WiFi is NOT connected; reconnecting now, trial: %u, delay: %u", trial, mydelay);
        initWiFi();      // use if auto-reconnect not working
        mydelay  = (mydelay > 100000) ? 100000 : mydelay * 1.2; // increase delay up to ~100 sec
        trial++;
        delay(mydelay);
    }
    // reset if WiFi is connected
    else{
        mydelay = 100;
        trial   = 1;
    }

    if (countOfDownloads >= 100){
        totalcountOfDnlds += countOfDownloads;
        cSF(stats, 100);
        stats.printf("%7.1f  %5u  %9u  %5u  %4u\n", millis() / 1000.0f, countOfBoots, countOfDownloads, totalcountOfDnlds, waitperiod);

        File crashfile = myFS->open("/crash.log", "a");
        crashfile.print(stats.c_str() );
        crashfile.close();
        countOfBoots = 0;
        countOfDownloads = 0;
    }

    yield();  // needed ?
}

