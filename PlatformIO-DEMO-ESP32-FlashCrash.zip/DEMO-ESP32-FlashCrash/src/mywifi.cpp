// mywifi.cpp

#include "mywifi.h"

void initWiFi(){

    NVSClass myNVSclass;

    Serial.flush();
    Serial.println(" ");

    log_i("Init WiFi");

    WiFi.persistent(false);     // store WiFi config in SDK flash area - does not seem to matter; define it anyway as not-storing
    // WiFi.persistent(true);   // store WiFi config in SDK flash area - does not seem to matter

    // Stop wifi
    log_i("   setting mode 'WIFI_OFF'");
    WiFi.mode(WIFI_OFF);
    delay(1);                                                       // give a moment to settle

    // Start wifi in station mode
    log_i("   setting mode 'WIFI_MODE_STA'");
    WiFi.mode(WIFI_MODE_STA);
    delay(1);                                                       // STA needs a moment to settle

    // check / change TX power
    log_i("   Default     TXPower:       %i", WiFi.getTxPower());   // default results in TX power = 80
    // WiFi.setTxPower(WIFI_POWER_19_5dBm);                         // results in TX power = 77
    // WiFi.setTxPower((wifi_power_t)80);                           // results in TX power = 77 (same as 19.5 dbm???)
    // WiFi.setTxPower(WIFI_POWER_2dBm);                            // results in TX power = 5

    // Enable automatic wifi reconnect
    log_i("   Default     AutoReconnect: %i", WiFi.getAutoReconnect());   // default is: true
    // WiFi.setAutoReconnect(true);
    // log_i("setting true: AutoReconnect(): %i", WiFi.getAutoReconnect());

    // Long Range Mode:
    // "This mode is an Espressif-patented mode which can achieve a one-kilometer line of
    // sight range. Please, make sure both the station and the AP are connected to an ESP device"
    // --> not relevant when connecting to router
    // https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-guides/wifi.html#wi-fi-protocol-mode
    //
    // enableLongRange(bool enable)
    // mod by ullix in WiFiGeneric.h:
    // bool getLongRange() { return _long_range; };
    // log_i("Default:    LongRange:     %i", WiFi.getLongRange());
    // WiFi.enableLongRange(true);                         // kein Effekt
    // WiFi.enableLongRange(false);                        // kein Effekt

    uint32_t t0, t2;
    float    dur = 0;

    t0 = micros();
        log_i("   1st WiFi.begin");
        WiFi.begin(WIFI_STATION_SSID, WIFI_STATION_PASSWORD);           // 1st WiFi.begin()
        WiFi.waitForConnectResult();
    dur = (micros() - t0)/1000.0f;

    log_i("   Status: %i, 1st Connect Result after: %4.0f ms", WiFi.status(), dur);

    if (WiFi.status() == 3) {
        // connected
        log_i("   Status: %i, Connected; no 2nd Connect needed", WiFi.status());
    }
    else{
        // NOT connected. Perhaps Double-hit needed, when ESP core 1.0.4 is used on FritzBox routers
        log_i("   2nd WiFi.begin");
        WiFi.begin(WIFI_STATION_SSID, WIFI_STATION_PASSWORD);           // 2nd WiFi.begin()

        t2 = micros();
        while (WiFi.status() != 3){delay(10);}                          // infinite(!) wait for connection
        dur = (micros() - t2)/1000.0f;
        log_i("   Status: %i, 2nd Connect Result after: %4.0f ms", WiFi.status(), dur);
    }

    IPAddress ip = WiFi.localIP();

    dur = (micros() - t0)/1000.0f;
    log_i("   Status: %i, Total Connect Result after: %4.0f ms, IP: %u.%u.%u.%u", WiFi.status(), dur, ip[0], ip[1], ip[2], ip[3]);
}

