// FlashCrash.h

// currently using the Espressif platform version 3.3.0

#pragma once

#include <Arduino.h>

#include <ESPAsyncWebServer.h>
#include <AsyncTCP.h>
#include <SafeString.h>
#include <esp_log.h>

/******************************************************************************
 * WiFi settings - replace with your own
 *****************************************************************************/
#define         WIFI_STATION_SSID               "mySSID"
#define         WIFI_STATION_PASSWORD           "myPassword"


//###################################################################################################
// FileSystem - activate one of FFat, LittleFS, or SPIFFS
// SPIFFS is useless for large files; at ~60% used space on 4MB Flash Watchdog triggers permanently
// !!! Make sure PARTITIONS settings match FS selection !!!

#define        myFSCode     1    // use FFat
// #define        myFSCode     2    // use SPIFFS
// #define        myFSCode     3    // use LittleFS

#if   myFSCode == 1                             // using the FFat file system
    #include "FFat.h"
    // fs::F_Fat       * myFS       = &FFat;    // use in main.cpp
    extern fs::F_Fat       * myFS;
    #define           myFSName     "FFat"

#elif myFSCode == 2                             // using the SPIFFS file system
    #include "SPIFFS.h"
    // fs::SPIFFSFS   *  myFS       = &SPIFFS;  // use in main.cpp
    extern fs::SPIFFSFS   *  myFS;
    #define           myFSName     "SPIFFS"

#elif myFSCode == 3                             // using the LittleFS file system
    #include "LITTLEFS.h"
    // fs::LITTLEFSFS  * myFS       = &LITTLEFS;// use in main.cpp
    extern fs::LITTLEFSFS  * myFS;
    #define           myFSName     "LittleFS"

#endif


/******************************************************************************
 * Defines and Variables
 *****************************************************************************/

// defines the file download being offered for:  saving (when true), display (when false)
#define     TREATMENT           false

// defines default data-file size in kibi bytes (1024 bytes)
#define     FILESIZE            300

// serial monitor baudrate
#define     SERIAL_BAUDRATE     115200

// wait period for web page refresh
#define     WAITSLOW            3000                            // slow
#define     WAITFAST            50                              // fast

// constants
extern const uint32_t           mibi;                           // MByte
extern const uint32_t           kibi;                           // KByte

// Flash Chip ID & Size
extern const uint32_t           FlashID;
extern const uint32_t           FlashSize;

// path to the Data file
extern const String             filePath;

// count of downloads of test data; stored in NVS
extern uint32_t                 countOfDownloads;              // count of downloads; stored in NVS

// count of boots; stored in NVS
extern uint32_t                 countOfBoots;                  // count of boots; stored in NVS

// waiting period; stored in NVS
extern uint32_t                 waitperiod;                    // to allow slowdown of webpage refreshing

