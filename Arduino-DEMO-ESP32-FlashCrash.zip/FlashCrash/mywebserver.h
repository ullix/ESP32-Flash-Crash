// mywebserver.h


#pragma once

#include "FlashCrash.h"
#include "mynvs.h"

#define           WEBSERVER_PORT          80                // Webserver port

void initWebServer();
String getPage_Web          (AsyncWebServerRequest *request);
String getPage_BinData      (AsyncWebServerRequest *request);
String getPage_Stats        (AsyncWebServerRequest *request);
void   resetStats           (AsyncWebServerRequest *request);
void   setWaitingPeriod     (AsyncWebServerRequest *request, uint16_t wait);

