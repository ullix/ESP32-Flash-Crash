// mywifi.h

#pragma once

#include <WiFi.h>

#include "FlashCrash.h"
#include "mynvs.h"

void initWiFi();