// myfilesystem.h

// Note: erase total flash with:   esptool.py erase_flash
//       get flash info with:      esptool.py flash_id
//       esptool.py location:      ~/.platformio/packages/tool-esptoolpy/esptool.py


#pragma once

#include "FlashCrash.h"
#include <FS.h>

class FSClass {
    public:
        FSClass();

        void initFileSystem();
        void makeCAMFile(uint32_t fsize, const char * fname);
        void addDirFileListSystem(SafeString & flist, const char * dirname, uint8_t level);
        void removeFile(const char * filename);
        bool formatFileSystem();
        bool removeFullDir(const char * dirname);
};

