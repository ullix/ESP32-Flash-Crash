// nvs.h

#pragma once

#include "FlashCrash.h"
#include <Preferences.h>                    // lib to use nvs memory


/*
 * https://docs.espressif.com/projects/esp-idf/en/latest/esp32/api-reference/storage/nvs_flash.html
 * Keys are ASCII strings; the maximum key length is currently 15 characters. Same for namespaces
*/
#define     NVSSTORAGE      "TestAsync"         // the namespaces; NVS storage name keys are stored
#define     NVSBOOTCOUNT    "countOfBoots"      // the key for boots
#define     NVSDNLDCOUNT    "countOfDnlds"      // the key for downloads
#define     NVSWAITPERIOD   "waitperiod"        // the key for downloads

class NVSClass {
    public:
        NVSClass();

        void        initNVS();
        void        endNVS();
        void        clearNVS();
        void        removeNVSKey(const char * key);
        void        saveStatsToNVS();
        void        getStatsFromNVS();
        uint16_t    getNVS_FreeEntries();
};

