// FlashCrash.h

// using the Espressif platform version 3.2.1
// 2021-07-08: updating zu Espressif platform version 3.3.0


#pragma once

#include <Arduino.h>

#include <ESPAsyncWebServer.h>              // needed here wg deferred
#include <AsyncTCP.h>
#include <SafeString.h>                     // avoiding the 'String' class
#include <esp_log.h>

/******************************************************************************
 * WiFi settings - replace with your own
 *****************************************************************************/

// FritzBox 7490
// #define         WIFI_STATION_SSID               "fb7490"
// #define         WIFI_STATION_PASSWORD           "69513346949661494501"
#define         WIFI_STATION_SSID               "fb75rw"
#define         WIFI_STATION_PASSWORD           "15574488725844453853"

// bq X5 smartphone hotspot
// #define              WIFI_STATION_SSID        "X5Plus_u"
// #define              WIFI_STATION_PASSWORD    "X5hotschpot"

// FritzBox 7272 blk
// #define              WIFI_STATION_SSID        "fb7272blk"
// #define              WIFI_STATION_PASSWORD    "28284831688862109781"


//###################################################################################################
// FileSystem - activate one of FFat, LittleFS, or SPIFFS
// SPIFFS is useless for large files; at ~60% used space on 4MB Flash Watchdog triggers permanently
// !!! Make sure PARTITIONS settings match FS selection !!!

#define        myFSCode     1    // use FFat
// #define        myFSCode     2    // use SPIFFS
// #define        myFSCode     3    // use LittleFS

#if   myFSCode == 1                             // using the FFat file system
    #include "FFat.h"
    // fs::F_Fat       * myFS       = &FFat;    // use in main.cpp
    extern fs::F_Fat       * myFS;
    #define           myFSName     "FFat"

#elif myFSCode == 2                             // using the SPIFFS file system
    #include "SPIFFS.h"
    // fs::SPIFFSFS   *  myFS       = &SPIFFS;  // use in main.cpp
    extern fs::SPIFFSFS   *  myFS;
    #define           myFSName     "SPIFFS"

#elif myFSCode == 3                             // using the LittleFS file system
    #include "LITTLEFS.h"
    // fs::LITTLEFSFS  * myFS       = &LITTLEFS;// use in main.cpp
    extern fs::LITTLEFSFS  * myFS;
    #define           myFSName     "LittleFS"

#endif


/******************************************************************************
 * Defines and Variables
 *****************************************************************************/

// defines the file download being offered for:  saving (when true), display (when false)
#define     TREATMENT           false

// defines default data-file size in kibi bytes (1024 bytes)
#define     FILESIZE            300

// path to test data
#define     DATA_PATH           "/Data"

// serial monitor baudrate
#define     SERIAL_BAUDRATE     115200

// wait period for web page refresh
#define     WAITSLOW            3000       // slow
#define     WAITFAST            100        // fast

// Flash Chip ID
extern uint32_t                 Flash_ID;

// path to the Data file
extern String                   filePath;

// uri for downloading file via JS
// extern String                   fileUri;

// count of downloads of test data; stored in NVS
extern uint32_t                 countOfDownloads;              // count of downloads; stored in NVS

// count of boots; stored in NVS
extern uint32_t                 countOfBoots;                  // count of boots; stored in NVS

// waiting period
extern uint32_t                 waitperiod;                    // to allow slowdown of webpage refreshing

// deferred web request
extern AsyncWebServerRequest*   ReqDeferred;

// constants
extern const uint32_t           mibi;                       // MByte
extern const uint32_t           kibi;                       // KByte

