// mywebserver.cpp

#include "mywebserver.h"

AsyncWebServer          wserver(WEBSERVER_PORT);     // instance of the webserver
AsyncWebServerRequest*  ReqDeferred = nullptr;       // deferred web request


void initWebServer(){
// configure and begin web server

    Serial.flush();
    Serial.println(" ");

    log_i("Init WebServer");

// get the root page
    wserver.on("/", HTTP_GET, [] (AsyncWebServerRequest *request) {request->send(200, "text/html",   getPage_Web(request));});

// favicon.ico (dummy "")
    wserver.on("/favicon.ico", HTTP_GET, [] (AsyncWebServerRequest *request) {request->send(200, "text/plain",   "");});

// download the data file via JS in a web page, and present in human readable format
    wserver.on("/DataByJS",     HTTP_GET, [] (AsyncWebServerRequest *request){request->send(200, "text/html",  getPage_BinData(request));});

// by JS
    wserver.on(filePath.c_str(), HTTP_GET, [](AsyncWebServerRequest* request){

            auto t0 = micros();

            log_i("JS started");

            countOfDownloads++;
            if (request != nullptr) request->send(*myFS, filePath.c_str(), String(), TREATMENT);  // TREATMENT: Download or Display
            else                    log_e("JS -- #%u - %s  REQUEST is NULLPTR!", countOfDownloads, filePath.c_str());

            NVSClass myNVSclass;
            myNVSclass.saveStatsToNVS();
            myNVSclass.getStatsFromNVS();

            float dur = (micros() - t0)/1000.0f;

            log_i("JS ended -- #%u - %s  dur:%0.0f ms  Core:%i  Boots:%i  Wait:%u"
                        , countOfDownloads
                        , filePath.c_str()
                        , dur
                        , xPortGetCoreID()
                        , countOfBoots
                        , waitperiod);
        });

// reset stats
    wserver.on("/resetStats", HTTP_GET, [] (AsyncWebServerRequest* request){resetStats(request);});

// get the stats
    wserver.on("/stats",        HTTP_GET, [] (AsyncWebServerRequest *request){request->send(200, "text/plain", getPage_Stats(request));});

// set the waiting period
    wserver.on("/slow" ,        HTTP_GET, [] (AsyncWebServerRequest *request){setWaitingPeriod(request, WAITSLOW);});
    wserver.on("/fast" ,        HTTP_GET, [] (AsyncWebServerRequest *request){setWaitingPeriod(request, WAITFAST);});

// Catch all other request
    wserver.onNotFound([](AsyncWebServerRequest *request){request->send(404, "text/html", "Not found");});

// Start the webserver. Needs wifimode > 0
    log_i("   Webserver begin");
    wserver.begin();
}


String getPage_Web(AsyncWebServerRequest *request){

    log_i("url: '%s'", request->url().c_str());

    cSF(html_data, 5000);

    html_data.printf((R"=====(
<!DOCTYPE html>
<html lang='en'>
<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=yes'>
<meta charset='utf-8' />
<style>
  html {font-family:Helvetica; display:inline-block; margin:0px auto; text-align:center; font-size:20px;}
</style>
<title>Download Test</title>

<h1><a href='/'>Download Test</a></h1>
<span style='color:red; font-weight:bold'>Flash Chip ID: %6x</span>
<br>
<span style='color:red; font-weight:normal'>Watch Serial Monitor for response messages!</span>
<br><br>
<div>Activate auto-downloading this link:</div>
<p> <a style='font-size:24px;' href='/DataByJS' target='_blank'>Download Data by JS</a>
<br><br>
<a href='/slow' >Slow</a>&nbsp;&nbsp;&nbsp;
<a href='/fast' >Fast</a>
<br>
<p> Wait-Period[ms] : %u</p>
<br>
<p>Count of Boots    : %u</p>
<p>Count of Downloads: %u</p>
<a href='/resetStats'>Reset Stats</a>
)=====")
            , Flash_ID
            , waitperiod, countOfBoots, countOfDownloads
        );

    return html_data.c_str();
}

// wait is WAITSLOW=3000 or WAITFAST=100 depending on which web link was clicked
void setWaitingPeriod(AsyncWebServerRequest *request, uint16_t wait){

    waitperiod = wait;
    NVSClass myNVSclass;
    myNVSclass.saveStatsToNVS();

    request->redirect("/");
}


String getPage_Stats(AsyncWebServerRequest *request){
// delivers countOfDownloads, countOfBoots, waitperiod as comma separated text

    cSF(stats, 200);
    stats.printf("%u, %u, %u"
                , countOfDownloads
                , countOfBoots
                , waitperiod
               );

    // log_i("getPage_Stats: %s", stats.c_str());
    return stats.c_str();
}


void resetStats(AsyncWebServerRequest *request){
// reset countOfBoots and countOfDownloads to 0 (zero)
// redirects to "/"

    log_i("on-Entry: Count of: Boots: %u,  Downloads: %u", countOfBoots, countOfDownloads);

    countOfBoots = 0;
    countOfDownloads = 0;

    NVSClass myNVSclass;
    myNVSclass.saveStatsToNVS();
    myNVSclass.getStatsFromNVS();

    log_i("on-Exit : Count of: Boots: %u,  Downloads: %u", countOfBoots, countOfDownloads);

    request->redirect("/");
}


/*
 * JS code for downloading binary data and printing in human readable format
 */
const char * JScodeBinData = R"=====(

async function getPage_Stats(){
        let fetchDataText = "";
        try{
            const fetchData = await fetch("stats", {cache: "no-store"});
            fetchDataText   = await fetchData.text();
            if (fetchDataText.startsWith("<!")) fetchDataText = "";
        }
        catch(error){
            console.log("ERROR: fetchRecord:", error);
        }
        return fetchDataText.split(",");
}

async function handleBinData(){

    console.log("handleBinData start, datasource: ", BinDataSource);

    let t0          = performance.now();
    let fetchdata   = 0;
    console.log("getting fetchdata ...:");
    try{
        fetchdata   = await fetch(BinDataSource, {cache: "no-store"});
    }
    catch (error){
        console.log("ERROR: @ fetchdata: error:        ", error);
        console.log("ERROR: @ fetchdata: error.name:   ", error.name);
        console.log("ERROR: @ fetchdata: error.message:", error.message);
    }
    console.log("... took[ms]:", (performance.now() - t0) );

    let tfb0        = performance.now();
    let fetchbuffer = 0;
    console.log("getting fetchbuffer ...");
    try{
        fetchbuffer     = await fetchdata.arrayBuffer();
    }
    catch(error){
        console.log("ERROR: @ fetchbuffer: error:        ", error);
        console.log("ERROR: @ fetchbuffer: error.name:   ", error.name);
        console.log("ERROR: @ fetchbuffer: error.message:", error.message);
    }
    console.log("... took[ms]:", (performance.now() - tfb0) );

    let t1              = performance.now();
    let dt              = t1 - t0;
    let fetchBytes      = fetchbuffer.byteLength;
    console.log("fetch overall: ", fetchBytes, "B ", dt.toFixed(1), "ms ", (fetchBytes/dt).toFixed(1), "kB/s" );
    // console.log(fetchbuffer);

    let utf8decoder = new TextDecoder(); // default 'utf-8' or 'utf8'
    let counter = 1;
    let reclen  = 32;
    let ddata   = "";
    for (let i = 0; i < fetchBytes; i += reclen){
        ddata += counter++ + " " + utf8decoder.decode(fetchbuffer.slice(i, i + reclen)) + "\n"
    }
    let t2              = performance.now();
    let dtjs            = t2 - t1;

    // console.log("ddata: len:", ddata.length, "\n", ddata);

    const statsdata     = await getPage_Stats();

    let strdata = "<pre>";
    strdata += "#Performance: Count of Downloads: " + statsdata[0] + ", Count of Boots: " + statsdata[1] + "\n";
    strdata += "#Binary Data in Human-Readable Format - " + BinDataSource + "\n";
    strdata += "#Download: " + fetchBytes/1024 +  " kB, " + fetchBytes +  " bytes, " + fetchBytes/reclen + " records, dur: " + dt.toFixed(0) + " ms, speed: " + (fetchBytes/dt).toFixed(0) + " kB/s\n";
    strdata += "#PageCalc:                                           " + dtjs.toFixed(0) + " ms\n"
    strdata += "#Overall:                                           " + (t2 - t0).toFixed(0) + " ms\n";
    strdata += ddata;

    document.body.innerHTML = strdata;

    // console.log("strdata: len:", strdata.length, "\n", strdata);

    return strdata.length;
}

async function showPage(){

    let t0      = performance.now();
    let lenData = await handleBinData();
    console.log("showPage: handleBinData: pagesize:", lenData, " took[ms]:", performance.now() - t0);

    let t2 = performance.now();
    const stats      = await fetch("/stats", {cache: "no-store"});
    const statsText  = await stats.text();
    console.log("showPage: statsText: ", statsText, ", took[ms]: ", performance.now() - t2);

    setTimeout(function(){location.reload(true);}, waitperiod);
}

showPage();
)=====";


String getPage_BinData(AsyncWebServerRequest *request){

    log_i("start getPage_BinData\n");

    String pagecode;

    // html header
    pagecode  =     "<!DOCTYPE html>\n"
                    "<html lang='en'>\n"
                    "<meta name='viewport' content='width=device-width, initial-scale=1.0, user-scalable=yes'>\n"
                    "<meta charset='utf-8'/>\n"
                    "<style> html {white-space:nowrap;} </style>\n"
                    "<title>CAM Data</title>\n";

    // html body
    pagecode +=     "<pre>Waiting for data ...</pre>\n";

    // html script (will use decoded Bin data to replace body)
    pagecode +=     "<script>\n";
    pagecode +=         "let waitperiod = "     + String(waitperiod)        + ";\n";
    pagecode +=         "let BinDataSource = '" + String(filePath.c_str())  + "';\n";
    pagecode +=         JScodeBinData;
    pagecode +=     "</script>\n";

    return pagecode.c_str();
}

