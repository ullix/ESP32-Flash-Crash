// javascript code to keep

// fetch with timeout:  https://dmitripavlutin.com/timeout-fetch-request/
async function fetchWithTimeout(resource, options) {
  const { timeout = 8000 } = options;

  const controller = new AbortController();
  const id = setTimeout(() => controller.abort(), timeout);

  console.log("fWT now fetching resource: ", resource);

  const response = await fetch(resource, {
    ...options,
    signal: controller.signal
  });
  clearTimeout(id);

  console.log("fWT now returning response: ", response);

  return response;
}

// usage of fetch with timeout
// ...
    let BinDataSource = "/Data/TEST300k.cam"; // url
    let fetchdata = 0;
    try {
        console.log("calling fetchdata with datasource: ", BinDataSource);
        fetchdata = await fetchWithTimeout(BinDataSource, {
                                                                cache: "no-store",
                                                                timeout: 3000
                                                                });
        console.log("got fetchdata: ", fetchdata);
    }
    catch (error) {
        // Timeouts if the request takes longer than 3 seconds
        // error.name === 'AbortError'
        console.log("TIMEOUT ERROR: @ fetchdata:", error);
    }
//...

