// mynvs.cpp     NVS - Non-Volatile-Storage - usage with lib: Preferences


#include "mynvs.h"

Preferences prefs;

NVSClass::NVSClass(){}

void NVSClass::initNVS(){
// init NVS storage

    Serial.flush();
    Serial.println(" ");

    log_i("Init NVS - freeEntries: %i", getNVS_FreeEntries());

    // from header: bool begin(const char * name, bool readOnly=false);
    //              readOnly=false => allow both read and write
    if (prefs.begin(NVSSTORAGE, false)){
        // NVS is ready
    }
    else{
        // NVS failed
        log_e("Failure initializing NVSSTORAGE");
    }

    getStatsFromNVS();
    if (waitperiod == 0) waitperiod = WAITFAST;
    countOfBoots++;
    saveStatsToNVS();

    log_i("   NVS Free Entries: %i,  NVS Boots: %u, NVS Downloads: %u, Waitperiod: %u", getNVS_FreeEntries(), countOfBoots, countOfDownloads, waitperiod);
}


void NVSClass::endNVS(){
    log_i("endNVS: ");
    prefs.end();
}


uint16_t NVSClass::getNVS_FreeEntries(){
    return prefs.freeEntries();
}


// from Preferences.cpp:  "Clear all keys in opened preferences"
void NVSClass::clearNVS(){
    log_i("clear NVS: ");
    prefs.clear();
}


// use key: NVSBOOTCOUNT
void NVSClass::removeNVSKey(const char * key){

    log_i("remove NVS key: %s", key);
    prefs.remove(key);
}


void NVSClass::saveStatsToNVS(){

    // size_t   putULong(const char* key, uint32_t value);
    prefs.putULong(NVSBOOTCOUNT, countOfBoots);
    prefs.putULong(NVSDNLDCOUNT, countOfDownloads);
    prefs.putULong(NVSWAITPERIOD, waitperiod);
}


void NVSClass::getStatsFromNVS(){

    // uint32_t getULong(const char* key, uint32_t defaultValue = 0);
    countOfBoots        = prefs.getULong(NVSBOOTCOUNT);
    countOfDownloads    = prefs.getULong(NVSDNLDCOUNT);
    waitperiod          = prefs.getULong(NVSWAITPERIOD);
}

