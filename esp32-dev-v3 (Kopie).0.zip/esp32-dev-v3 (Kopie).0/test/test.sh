#!/bin/bash
# start with: /test.sh <use case> <number of tests>
# like:  ./test.sh uc1 10000


LC_NUMERIC=C

# serverIpAddress="10.0.0.55"           # (PICO)
# serverIpAddress="10.0.0.75"           #
# serverIpAddress="10.0.0.78"           #
# serverIpAddress="10.0.0.85"           #
# serverIpAddress="10.0.0.97"           # (WROVER)
serverIpAddress="10.0.0.101"          # fb7490
# serverIpAddress="10.0.0.102"          # fb7490
# serverIpAddress="10.0.0.103"          # fb7490
# serverIpAddress="10.0.0.104"          # fb7490
# serverIpAddress="192.168.43.14"       # X5 smartphone
# serverIpAddress="192.168.188.25"      # fb7272

#DataFilename="TEST900k.cam"
#DataFilename="TEST500k.cam"
DataFilename="TEST300k.cam"
#DataFilename="TEST250k.cam"
# DataFilename="TEST200k.cam"
#DataFilename="TEST160k.cam"
#DataFilename="TEST150k.cam"
#DataFilename="TEST140k.cam"
#DataFilename="TEST130k.cam"
#DataFilename="TEST120k.cam"
#DataFilename="TEST100k.cam"
#DataFilename="TEST90k.cam"
#DataFilename="TEST50k.cam"

useCase=$1
numberOfTests=$2
failCounter=0
successCounter=0

if [ -z "${useCase}" ]; then
    useCase="uc1"
fi

if [ -z "${numberOfTests}" ]; then
    numberOfTests=10
fi

echo "using file: " $DataFilename "with use case:" $useCase "getting:" $numberOfTests "Downloads"

for i in $(seq 1 ${numberOfTests})
do
    date_stamp=$(date +%T)
    echo -n "$date_stamp $useCase #${i}"
    url=http://${serverIpAddress}/download/${useCase}/${DataFilename}
    # response=$(curl -o /dev/null -m 19.99 -s --fail -w "%{time_total};%{speed_download};%{size_download}\n" -LO -X GET $url);
    response=$(curl -o /dev/null -m 29.99 -s --fail -w "%{time_total};%{speed_download};%{size_download}\n" -LO -X GET $url);
    res=$?

    #echo "response: ", $response
    #echo "res:      ", $response

    IFS=';' read -ra ADDR <<< "${response}"
    totalTime=${ADDR[0]}      # [s]
    downloadSpeed=${ADDR[1]}  # [B/s]
    downloadSize=${ADDR[2]}   # [Bytes]

    if   [ 0 -eq $res ]; then
        let successCounter++
        echo -n " Successful: "

    elif [ 28 -eq $res ]; then
        let failCounter++
        echo -n " Timeout___: "

    else
        let failCounter++
        echo -n " Failed____: "

    fi
    echo -n "${totalTime}s ${downloadSpeed}B/s ${downloadSize} Bytes"
    echo -n " Totals: S:${successCounter}  F:${failCounter}  -->  %"
    echo "scale=2 ; (100 * $successCounter / $((successCounter +failCounter)))" | bc

    sleep 0.1s
done

echo -n "$useCase $DataFilename Total: ${numberOfTests}, Successful: ${successCounter}, Failed: ${failCounter}  -->  %"
echo "scale=2 ; (100 * $successCounter / $numberOfTests)" | bc
echo
echo

